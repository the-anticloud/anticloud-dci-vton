# 25 Millennium Problem Proposals

**Project:** DCI_VTON
**Upstream:** https://github.com/KiseKloset/DCI-VTON

Content specific to DCI_VTON in category CLOTHING_RETAIL.
