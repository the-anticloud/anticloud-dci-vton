# 14 Developer Cookbooks

**Project:** DCI_VTON
**Upstream:** https://github.com/KiseKloset/DCI-VTON

Content specific to DCI_VTON in category CLOTHING_RETAIL.
